import './App.css';
import MaterialForm from './componentes/menu';
import Header from './componentes/header';
import Pesquisa from './componentes/pesquisa';



function App() {
  return (
    <div className="App">
      <header>
        <Pesquisa/>
        <Header/> 
      </header>     
        <div className='box' alt='box'>
          <MaterialForm></MaterialForm>
        </div>
    </div>
  );
}

export default App;

