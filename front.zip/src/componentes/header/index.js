import Opcoes from '../opcoes';
import Logo from '../logo';

function Header() {
    return(
        <header className='App-header'>
            <Logo/>
            <Opcoes/>
                           
      </header>
      )
}

export default Header;