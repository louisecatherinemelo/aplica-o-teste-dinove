import React, {useState, useEffect} from "react";
import axios from "axios";

function ItemList(){
    const [itens, setItens] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        axios.get('http://localhost:3001/itens')
        .then(response => {
            setItens(response.data);
            setLoading(false);            
        })
        .catch(error => {
            console.error(error);
            setLoading(false);
        });
    }, []);

    if(loading) {
        return <div> Carregando...</div>
    }

    return(
        <div>
            <h1> Lista de materiais</h1>
            <ul>
                {itens.map(itens => (
                    <li key= {itens.id}> { itens.name } </li>
                ))}
            </ul>
        </div>
    )

}

export default ItemList;